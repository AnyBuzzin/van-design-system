#!/bin/bash
# usage: vt.sh STAGE LABEL W H D PLY DADO [extra verifier args]
cd /c/Users/Buzz/Documents/VanDesign-G3/G3-run
case "$1" in
 F2) V="--doc v5-g3-tall --variant tall --schema 0.2 --shelves 3 --doors 1 --nchecks 112 --hash 4026125d3a279b956198cb9620ca30397bc88d6be4de9aef756687530a638eb0 --ref report_20261014_221815_930645_build";;
 F3) V="--doc v5-g3-overhead --variant overhead --schema 0.2 --shelves 1 --doors 2 --nchecks 62 --hash 6c15b5e34fdedbff55f796d416f4c3dc89a3109b58b71d264df668a4d322c2b2 --ref $F3REF";;
 F0) V="--doc v5-g3-legacy-ae --variant base --schema 0.1 --shelves 1 --doors 2 --nchecks 59 --hash a0a43e005535b33f069dd786dc847682734819a09bd0803650688bb5e4b0a750 --ref $F0REF";;
esac
st=$1; lb=$2; shift 2; d="$1 $2 $3 $4 $5"; shift 5
py -I verify_g3.py $st "$lb" --mode measure $V --dims $d "$@"
