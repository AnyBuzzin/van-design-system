"""Read-only check of the newest VanDesignCutAuditG3 report."""
import glob, json, os, sys, hashlib
D = r"C:\Users\Buzz\Documents\VanDesign-G3\4d4345b\VanDesignCutAuditG3\reports"
stage, doc, nops, shelves = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
base = sorted(glob.glob(os.path.join(D, "cut_audit_g3_*.json")))[-1][:-5]
j = json.load(open(base + ".json")); t = open(base + ".txt", encoding="utf-8").read()
res = []
def ok(c, m): res.append(bool(c)); print(("  OK  " if c else "  BAD ") + m)
print("== [%s] cut audit : %s" % (stage, os.path.basename(base)))
sha = {e: hashlib.sha256(open(base + e, "rb").read()).hexdigest() for e in (".json", ".txt")}
for e in sha: print("  sha256 %s%s %s" % (os.path.basename(base), e, sha[e]))
ok(j["document_name"] == doc, "document %s" % j["document_name"])
exp = {}
for k in range(1, shelves + 1):
    exp["dado.shelf%d.left" % k] = "panel.left.001"; exp["dado.shelf%d.right" % k] = "panel.right.001"
ok(j["expected_operations"] == exp and len(exp) == nops, "expected operations = %d (%s)" % (len(exp), sorted(exp)))
r = j["results"]
ok(len(r) == nops and all(x["status"] == "PASS" for x in r) and {x["operation_id"] for x in r} == set(exp), "%d/%d operations PASS, no unexpected dado features" % (sum(x["status"] == "PASS" for x in r), len(r)))
for x in r:
    d = x["details"]; parts = [l for l in d if l.strip().startswith("Body:")]
    ok(len(parts) == 1 and ("stable id: '%s'" % exp[x["operation_id"]]) in parts[0] and "shelf" not in parts[0].lower() and "Operation Cut: True" in d and "Participant count: 1" in d,
       "%s -> %s" % (x["operation_id"], parts[0].strip() if parts else "?"))
ok(j["timeline_restored"] is True and j["restore_error"] is None and j["collect_error"] is None and j["start_marker"] == j["start_count"], "timeline restored (marker %s/%s), no errors" % (j["start_marker"], j["start_count"]))
ok(j["counts_before"] == j["counts_after"], "counts before == after %s" % json.dumps(j["counts_after"], sort_keys=True))
ok(j["overall"] == "PASS" and ("Features passed: %d/%d" % (nops, nops)) in t and "OVERALL: PASS" in t, "OVERALL PASS, Features passed %d/%d" % (nops, nops))
row = {"stage": stage, "test": "%s cut audit" % stage, "report": os.path.basename(base), "mode": "audit", "doc": j["document_name"],
       "pass": sum(x["status"] == "PASS" for x in r), "nchecks": len(r), "fail": sum(x["status"] == "FAIL" for x in r), "unknown": sum(x["status"] == "UNKNOWN" for x in r),
       "counts": j["counts_after"], "timeline_restored": j["timeline_restored"], "sha256_json": sha[".json"], "sha256_txt": sha[".txt"],
       "verdict": "PASS" if all(res) else "FAIL"}
open(r"C:\Users\Buzz\Documents\VanDesign-G3\G3-run\results.jsonl", "a").write(json.dumps(row) + "\n")
print("VERDICT:", row["verdict"]); sys.exit(0 if all(res) else 1)
