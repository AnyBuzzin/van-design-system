"""Read-only verifier for one VanCabinetJoineryV5 G3 report.

Recomputes every Cab_* value independently from W/H/D/ply/dado + shelf count,
checks mode, document, variant, schema, hash, named-check counts/status,
managed entities, design counts (vs a reference report) and stored-spec
stability. Appends one JSON row per report to results.jsonl.
Never edits any report.
"""
import argparse, glob, hashlib, json, os, sys

REP = r"C:\Users\Buzz\Documents\VanDesign-G3\4d4345b\VanCabinetJoineryV5\reports"
OUT = r"C:\Users\Buzz\Documents\VanDesign-G3\G3-run\results.jsonl"

ap = argparse.ArgumentParser()
ap.add_argument("stage"); ap.add_argument("label")
ap.add_argument("--mode", required=True, choices=["build", "measure"])
ap.add_argument("--doc", required=True)
ap.add_argument("--variant", required=True)
ap.add_argument("--schema", required=True)
ap.add_argument("--dims", nargs=5, type=float, required=True, metavar=("W", "H", "D", "PLY", "DADO"))
ap.add_argument("--shelves", type=int, required=True)
ap.add_argument("--doors", type=int, required=True)
ap.add_argument("--nchecks", type=int, required=True)
ap.add_argument("--hash", required=True, help="expected design_spec_hash")
ap.add_argument("--ref", help="reference report base name for design_counts / expressions")
ap.add_argument("--expect-fail", help="exactly this one check id must FAIL (negative test)")
ap.add_argument("--report", help="explicit report base name; default latest of --mode")
a = ap.parse_args()

base = a.report or sorted(glob.glob(os.path.join(REP, "report_*_%s.json" % a.mode)))[-1][:-5]
base = base if os.path.isabs(base) else os.path.join(REP, base)
j = json.load(open(base + ".json")); t = open(base + ".txt", encoding="utf-8").read()
ref = json.load(open(os.path.join(REP, a.ref + ".json"))) if a.ref else None
res = []
def ok(c, m):
    res.append(bool(c)); print(("  OK  " if c else "  BAD ") + m)

print("== [%s] %s : %s" % (a.stage, a.label, os.path.basename(base)))
sha = {}
for ext in (".json", ".txt"):
    d = open(base + ext, "rb").read(); sha[ext] = hashlib.sha256(d).hexdigest()
    print("  sha256 %s%s %s" % (os.path.basename(base), ext, sha[ext]))

W, H, D, PLY, DADO = a.dims; n = a.shelves
BACK, GAP, SLOT, END = 6.0, 3.0, 0.5, 0.3
exp = {"Cab_Width": W, "Cab_Height": H, "Cab_Depth": D, "Cab_Ply": PLY, "Cab_Dado_Depth": DADO,
       "Cab_Back": BACK, "Cab_Gap": GAP, "Cab_Slot_Clearance": SLOT, "Cab_End_Clearance": END,
       "Cab_Inner_Depth": D - BACK, "Cab_Slot_Height": PLY + SLOT, "Cab_Shelf_X": PLY - DADO + END,
       "Cab_Shelf_Length": W - 2 * PLY + 2 * DADO - 2 * END}
if n:
    exp["Cab_Compartment"] = (H - (n + 2) * PLY) / (n + 1)
    for k in range(1, n + 1):
        exp["Cab_Shelf%d_Z" % k] = PLY + k * exp["Cab_Compartment"] + (k - 1) * PLY
        exp["Cab_Slot%d_Z" % k] = exp["Cab_Shelf%d_Z" % k] - SLOT / 2

ok(j["mode"] == a.mode and ("Mode: %s" % a.mode) in t, "mode %s" % a.mode)
ok(j["document_name"] == a.doc, "document %s (report: %s)" % (a.doc, j["document_name"]))
ok(j.get("variant") == a.variant and j.get("profile_version") == 1 and j.get("design_schema_version") == a.schema,
   "variant %s@1, design schema %s (report: %s@%s, %s, migrated=%s)" % (a.variant, a.schema, j.get("variant"), j.get("profile_version"), j.get("design_schema_version"), j.get("migrated_in_memory")))
sp = j["spec"]["parameters"]
ok(sp["shelf_count"] == n and sp["door_count"] == a.doors, "stored spec: %d shelves, %d doors" % (sp["shelf_count"], sp["door_count"]))
P = {k: v["value_mm"] for k, v in j["parameters_read_from_fusion"].items()}
bad = {k: (P.get(k), e) for k, e in exp.items() if P.get(k) is None or abs(P[k] - e) > 1e-6}
extra = sorted(set(P) - set(exp))
ok(not bad and not extra, "%d live Cab_* params == independently computed" % len(P) + ("" if not bad else " MISMATCH %s" % bad) + ("" if not extra else " UNEXPECTED %s" % extra))
if ref:
    RE = {k: v["expression"] for k, v in ref["parameters_read_from_fusion"].items()}
    JE = {k: v["expression"] for k, v in j["parameters_read_from_fusion"].items()}
    print("  expressions differing from reference:", {k: (RE.get(k), JE.get(k)) for k in set(RE) | set(JE) if RE.get(k) != JE.get(k)} or "none")

v = j["validation"]; c = v["checks"]; ids = [x["check_id"] for x in c]
fails = [x for x in c if x["status"] == "FAIL"]; unk = [x for x in c if x["status"] == "UNKNOWN"]
ok(len(c) == a.nchecks and len(set(ids)) == len(ids), "%d named checks (expected %d), all unique" % (len(c), a.nchecks))
if ref:
    ok(ids == [x["check_id"] for x in ref["validation"]["checks"]], "same check ids/order as reference")
if a.expect_fail:
    f = fails[0] if len(fails) == 1 else None
    ok(f is not None and f["check_id"] == a.expect_fail and not unk and v["verdict"] == "FAIL",
       "NEGATIVE: exactly one FAIL = %s, 0 UNKNOWN, verdict FAIL (got FAIL=%s UNKNOWN=%d)" % (a.expect_fail, [x["check_id"] for x in fails], len(unk)))
    if f:
        print("    observed=%s limit_min=%s limit_max=%s note=%r" % (f["observed"], f.get("limit_min"), f.get("limit_max"), f["note"]))
else:
    ok(not fails and not unk and v["verdict"] == "PASS" and v["counts"]["PASS"] == a.nchecks and ("RESULT: PASS - all %d checks passed" % a.nchecks) in t,
       "%d/%d PASS, 0 FAIL, 0 UNKNOWN" % (v["counts"]["PASS"], len(c)))
ok(v["diagnostics"] == [], "no diagnostics")
geo = [x for x in c if x["check_id"].startswith(("panel.", "dado.", "interference."))]
probes = [x for x in geo if ".probe." in x["check_id"]]
ok(all(x["status"] == "PASS" for x in geo) and len(probes) == 12 * n, "%d solid-geometry checks PASS incl. %d probes (%d dado ops)" % (len(geo), len(probes), 2 * n))
m = c[ids.index("entities.managed_ids")]
nent = 5 + n + a.doors  # left,right,bottom,top,back + shelves + doors
ok(m["status"] == "PASS" and m["observed"] == m["expected"] == float(nent), "entities.managed_ids PASS %s/%s (expect %d)" % (m["observed"], m["expected"], nent))
rng = [x for x in c if x["check_id"].startswith("profile.")]
print("  range checks:", [(x["check_id"], x["status"], x["observed"], x.get("limit_min"), x.get("limit_max")) for x in rng] or "none")
dc = j["design_counts"]
if ref:
    ok(dc == ref["design_counts"], "design counts %s == reference" % json.dumps(dc, sort_keys=True))
else:
    print("  design counts:", json.dumps(dc, sort_keys=True))
ok(j["design_spec_hash"] == a.hash, "design_spec_hash %s..." % a.hash[:16])
s = j["stored_spec"]
if a.mode == "measure":
    ok(s["raw_sha256_before"] == s["raw_sha256_after"] and s["unchanged"] is True and "Stored spec unchanged: True" in t, "stored_spec unchanged (before == after)")
else:
    ok(s["raw_sha256_after"] is not None and s["raw_sha256_before"] is None, "build stored spec raw sha256 %s" % s["raw_sha256_after"])

row = {"stage": a.stage, "test": a.label, "report": os.path.basename(base), "mode": j["mode"], "doc": j["document_name"],
       "variant": "%s@%s" % (j.get("variant"), j.get("profile_version")), "schema": j.get("design_schema_version"),
       "dims": [P.get("Cab_Width"), P.get("Cab_Height"), P.get("Cab_Depth"), P.get("Cab_Ply"), P.get("Cab_Dado_Depth")],
       "shelf_length": P.get("Cab_Shelf_Length"), "compartment": P.get("Cab_Compartment"),
       "pass": v["counts"]["PASS"], "fail": v["counts"]["FAIL"], "unknown": v["counts"]["UNKNOWN"], "nchecks": len(c),
       "fail_ids": [x["check_id"] for x in fails], "managed": m["observed"], "counts": dc,
       "design_spec_hash": j["design_spec_hash"], "stored_unchanged": s.get("unchanged"),
       "sha256_json": sha[".json"], "sha256_txt": sha[".txt"],
       "expected_negative": a.expect_fail, "verdict": "PASS" if all(res) else "FAIL"}
with open(OUT, "a") as fh:
    fh.write(json.dumps(row) + "\n")
print("VERDICT:", row["verdict"])
sys.exit(0 if row["verdict"] == "PASS" else 1)
