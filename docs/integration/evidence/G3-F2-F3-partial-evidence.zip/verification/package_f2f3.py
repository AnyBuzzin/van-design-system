"""Package the completed F2/F3 G3 evidence (read-only on reports) with a summary."""
import hashlib
import json
import os
import zipfile

REP = r"C:\Users\Buzz\Documents\VanDesign-G3\4d4345b\VanCabinetJoineryV5\reports"
AUD = r"C:\Users\Buzz\Documents\VanDesign-G3\4d4345b\VanDesignCutAuditG3\reports"
RUN = r"C:\Users\Buzz\Documents\VanDesign-G3\G3-run"
OUT = r"C:\Users\Buzz\Documents\VanDesign-G3\G3-F2-F3-partial-evidence.zip"
assert not os.path.exists(OUT), "zip already exists"

rows = [json.loads(line) for line in open(os.path.join(RUN, "results.jsonl"))]
L = [
    "# VanDesign G3 - F2 tall / F3 overhead partial Fusion evidence",
    "",
    "Source commit `4d4345b6cde6084b1731c5298fa50d70759ef061`. Generator installed at",
    "`Documents/VanDesign-G3/4d4345b/VanCabinetJoineryV5`, audit at `Documents/VanDesign-G3/4d4345b/VanDesignCutAuditG3`.",
    "Fusion 2705.1.30. Testing was **stopped by the project owner** part-way through F3.",
    "This is NOT full G3 verification and NOT manufacturing approval. Issue #4 stays open; PR #5 stays draft.",
    "",
    "Every report was checked by `verify_g3.py` / `verify_audit.py` (included): each live `Cab_*` value recomputed",
    "independently, named-check counts and statuses, managed entities, design counts vs the build report,",
    "design-spec hash, and stored spec before == after.",
    "",
    "## Test matrix",
    "",
    "| Stage | Test | Report | Checks PASS/total | FAIL ids | Result |",
    "|---|---|---|---|---|---|",
]
for r in rows:
    fails = r.get("fail_ids") if isinstance(r.get("fail_ids"), list) else []
    res = "PASS (expected negative FAIL)" if r.get("expected_negative") else r["verdict"]
    L.append("| %s | %s | `%s` | %s/%s | %s | %s |" % (
        r["stage"], r["test"], r["report"], r["pass"], r["nchecks"], ", ".join(fails) or "-", res))
for stage, test in [
        ("F3", "depth 350 -> 400 and restore"),
        ("F3", "height 400 -> 500 and restore"),
        ("F3", "negative height 800 (`profile.overhead.height_range`) and restore"),
        ("F3", "save / close / reopen / measure"),
        ("F3", "independent cut audit (2/2)"),
        ("F0", "legacy A-E regression under G3 (incl. 15 mm ply / 8 mm dado -> 1185.4 mm)")]:
    L.append("| %s | %s | - | - | - | **DEFERRED** |" % (stage, test))

L += [
    "",
    "## Summary",
    "",
    "- **Completed and passed:** F2 tall: build (112/112), 2 repeats, all 5 scalar edit/restore pairs "
    "(dado 10, ply 15, width 700, depth 600, height 2000 giving `Cab_Compartment` 477.5), negative test, "
    "post-negative restore, save/close/reopen measure, cut audit 6/6. F3 overhead: build (62/62, shelf 975.4, "
    "compartment 173), 2 repeats, and the dado 10, ply 15 and width 1100 edit/restore pairs.",
    "- **Expected negative failure:** F2 `Cab_Height` = 2300 gave exactly one FAIL, `profile.tall.height_range` "
    "(observed 2300, limits 1400-2200), 0 UNKNOWN, all 111 other checks PASS. The parameter stayed 2300 (not "
    "auto-corrected). Restored to 1900: 112/112 PASS.",
    "- **Unexpected failures:** none.",
    "- **Counts stable:** tall 20 params / 9 root occurrences / 10 components / 39 timeline items in every report; "
    "overhead 16 / 8 / 9 / 28. `entities.managed_ids` 9/9 (tall) and 8/8 (overhead) on every run; stored spec "
    "unchanged in every measurement.",
    "- **Hashes:** tall `4026125d3a279b956198cb9620ca30397bc88d6be4de9aef756687530a638eb0`, overhead "
    "`6c15b5e34fdedbff55f796d416f4c3dc89a3109b58b71d264df668a4d322c2b2`; both match the offline G3 loader; "
    "schema 0.2, not migrated.",
    "- **Saved state:** `v5-g3-tall` was saved at its restored baseline (22:35:26), closed, reopened and measured "
    "112/112. After the audit its open tab shows `*` only because the audit moved and restored the timeline "
    "marker; it was not saved, so the saved version is the verified baseline. `v5-g3-overhead` was saved at its "
    "verified baseline after the width restore (all five base values read back in Change Parameters; the last "
    "measurement, 22:47:31, matched the build expressions exactly). Its save/reopen *test* is DEFERRED.",
    "- **Cut audits:** F2 PASS 6/6 (each `dado.shelfN.left/right` cuts exactly one body, `panel.left.001` / "
    "`panel.right.001`, never a shelf; timeline marker 39/39 restored; counts before == after). F3 audit DEFERRED.",
    "- **Spec file left installed:** `cabinet_spec.json` beside the generator is currently the committed "
    "`specs/overhead.json` (blob `88718d5`). It only affects a *new* build. Earlier copies are in `spec-backups/`.",
    "- **Limitations:** fixture sizes only; width/depth/height edit values were chosen inside each profile's "
    "provisional range (the protocol does not fix them); F0 A-E under G3 not run; no manual UI inspection.",
    "",
    "## Files",
    "",
]

files = []
for r in rows:
    folder = AUD if r["report"].startswith("cut_audit") else REP
    for ext in (".txt", ".json"):
        files.append((os.path.join(folder, r["report"] + ext), "reports/" + r["report"] + ext))
for name in ("verify_g3.py", "verify_audit.py", "vt.sh", "results.jsonl", "package_f2f3.py"):
    files.append((os.path.join(RUN, name), "verification/" + name))
for name in sorted(os.listdir(os.path.join(RUN, "spec-backups"))):
    files.append((os.path.join(RUN, "spec-backups", name), "spec-backups/" + name))
for src, arc in files:
    L.append("- `%s` sha256 `%s`" % (arc, hashlib.sha256(open(src, "rb").read()).hexdigest()))

summary = os.path.join(RUN, "G3-F2-F3-partial-summary.md")
open(summary, "w", encoding="utf-8").write("\n".join(L) + "\n")
files.append((summary, "G3-F2-F3-partial-summary.md"))

with zipfile.ZipFile(OUT, "x", zipfile.ZIP_DEFLATED) as z:
    for src, arc in files:
        z.write(src, arc)
ok = True
with zipfile.ZipFile(OUT) as z:
    for src, arc in files:
        ok &= z.read(arc) == open(src, "rb").read()
print("files", len(files), "| byte-identical:", ok, "| zip sha256", hashlib.sha256(open(OUT, "rb").read()).hexdigest())
